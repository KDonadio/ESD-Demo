/*******************************************************************************
  Application BLE Profile Source File

  Company:
    Microchip Technology Inc.

  File Name:
    app_trsps_handler.c

  Summary:
    This file contains the Application BLE functions for this project.

  Description:
    This file contains the Application BLE functions for this project.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
* Copyright (C) 2018 Microchip Technology Inc. and its subsidiaries.
*
* Subject to your compliance with these terms, you may use Microchip software
* and any derivatives exclusively with Microchip products. It is your
* responsibility to comply with third party license terms applicable to your
* use of third party software (including open source software) that may
* accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
* EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
* WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
* PARTICULAR PURPOSE.
*
* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
* INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
* WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
* BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
* FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
* ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/
// DOM-IGNORE-END

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************
#include <string.h>
#include <stdio.h>
#include "stdint.h"
#include "ble_trsps.h"
#include "osal/osal_freertos_extend.h"
#include "definitions.h"

#include "../BLE_ESD.X/myapp.h"         // KJD ADDED

#define APP_LED_RED_ON          GPIOB_REGS->GPIO_PORTSET = 0x01;
#define APP_LED_RED_OFF         GPIOB_REGS->GPIO_PORTCLR = 0x01;
#define APP_LED_GREEN_ON        GPIOB_REGS->GPIO_PORTSET = 0x08;
#define APP_LED_GREEN_OFF       GPIOB_REGS->GPIO_PORTCLR = 0x08;
#define APP_LED_BLUE_ON         GPIOB_REGS->GPIO_PORTSET = 0x20;
#define APP_LED_BLUE_OFF        GPIOB_REGS->GPIO_PORTCLR = 0x20;


// *****************************************************************************
// *****************************************************************************
// Section: Global Variables
// *****************************************************************************
// *****************************************************************************
uint8_t rx_data[6];

// *****************************************************************************
// *****************************************************************************
// Section: Functions
// *****************************************************************************
// *****************************************************************************

void APP_TrspsEvtHandler(BLE_TRSPS_Event_T *p_event)
{
    switch(p_event->eventId)
    {
        case BLE_TRSPS_EVT_CTRL_STATUS:
        {
            /* TODO: implement your application code.*/
        }
        break;
        
        case BLE_TRSPS_EVT_TX_STATUS:
        {
            /* TODO: implement your application code.*/
        }
        break;

        case BLE_TRSPS_EVT_CBFC_ENABLED:
        {
            /* TODO: implement your application code.*/
        }
        break;
        
        case BLE_TRSPS_EVT_CBFC_CREDIT:
        {
            /* TODO: implement your application code.*/
        }
        break;
        
        //---------------------------------------------------------------------- START APP CODE HERE - KJD
        // BLE Data is Received here
        //----------------------------------------------------------------------                
        case BLE_TRSPS_EVT_RECEIVE_DATA:
            {
            uint16_t data_len;
            uint8_t *data;
            uint8_t pwm_duty;
            char buffer[25];

            // Retrieve received data length
            BLE_TRSPS_GetDataLength(p_event->eventField.onReceiveData.connHandle, &data_len);

            // Allocate memory according to data length
            data = OSAL_Malloc(data_len);

            if(data == NULL)
                break;

            // Retrieve received data
            BLE_TRSPS_GetData(p_event->eventField.onReceiveData.connHandle, data);

            // Should have the received data packet here ready to parse
            switch(data[0])
                {
                //------------------------------------------------------
                // RGB LED Commands
                case 'L':                       // LED Command
                    if(data[1] == 'R')          // RED
                        {
                        if(data[2] == '1')
                            {
                            SERCOM0_USART_Write((void*)"Red LED On\n", 11);	 // Red LED is on
                            APP_LED_RED_ON;
                            }
                        //
                        if(data[2] == '0')
                            {
                            SERCOM0_USART_Write((void*)"Red LED Off\n", 12);	 // Red LED is off
                            APP_LED_RED_OFF;
                            }              
                        }
                    //
                    if(data[1] == 'G')          // GREEN
                        {
                        if(data[2] == '1')
                            {
                            SERCOM0_USART_Write((void*)"Green LED On\n", 13);	 // Green LED is on
                            APP_LED_GREEN_ON;
                            }
                        //
                        if(data[2] == '0')
                            {
                            SERCOM0_USART_Write((void*)"Green LED Off\n", 14);	 // Green LED is off
                            APP_LED_GREEN_OFF;
                            }              
                        }
                    //
                    if(data[1] == 'B')          // BLUE
                        {
                        if(data[2] == '1')
                            {
                            SERCOM0_USART_Write((void*)"Blue LED On\n", 12);	 // Blue LED is on
                            APP_LED_BLUE_ON;
                            }
                        //
                        if(data[2] == '0')
                            {
                            SERCOM0_USART_Write((void*)"Blue LED Off\n", 13);	 // Blue LED is off
                            APP_LED_BLUE_OFF;
                            }              
                        }
                    break;
//                //------------------------------------------------------
//                // PWM Command
//                case 'P':                       // LED Command
//                    {
//                    pwm_duty = (((data[1]-0x30) * 100) + ((data[2]-0x30) * 10) + (data[3]-0x30));   
//                    sprintf(buffer, "PWM: %d \n", pwm_duty);
//                    SERCOM0_USART_Write((void*)buffer, 10);     // PWM                                         
//                    TCC0_REGS->TCC_CCBUF[0] = (uint8_t)(pwm_duty * 2.55F);         // PWM CH 0 duty cycle
//                    }
                //------------------------------------------------------
                // Default
                default:   
                    break;                   
                //-----------------------------------------------------                       
                }                
            
            // Free memory
            OSAL_Free(data);
        }
        break;
        
        case BLE_TRSPS_EVT_VENDOR_CMD:
        {
            /* TODO: implement your application code.*/
        }
        break;
       
        default:
        break;
    }
}