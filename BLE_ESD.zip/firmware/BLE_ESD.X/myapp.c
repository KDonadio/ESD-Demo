//------------------------------------------------------------------------------
// RGB LED Code for the Chimera Curiosity Board
// 6/29/2022 - Keith Donadio    
//------------------------------------------------------------------------------
#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include <stdio.h>
#include "definitions.h"                // SYS function prototypes
#include "ble_gap.h"
#include "ble_trsps/ble_trsps.h"
#include "../BLE_ESD.X/myapp.h"         // KJD ADDED

// For MCP9700
#include <stdint.h>
#include "math.h"
#include "peripheral/adchs/plib_adchs.h"

//------------------------------------------------------------------------------
// Defines for LED control
#define APP_LED_RED_ON          GPIO_PinSet(GPIO_PIN_RB0);      
#define APP_LED_RED_OFF         GPIO_PinClear(GPIO_PIN_RB0);    
#define APP_LED_GREEN_ON        GPIO_PinSet(GPIO_PIN_RB3);
#define APP_LED_GREEN_OFF       GPIO_PinClear(GPIO_PIN_RB3);
#define APP_LED_BLUE_ON         GPIO_PinSet(GPIO_PIN_RB5);
#define APP_LED_BLUE_OFF        GPIO_PinClear(GPIO_PIN_RB5);
// Blue User LED used for BLE connection Status
#define APP_LED_BLE_ON          GPIO_PinSet(GPIO_PIN_RB7);
#define APP_LED_BLE_OFF         GPIO_PinClear(GPIO_PIN_RB7);


#define SWITCH_Get()            ((GPIO_PortRead(GPIO_PORT_B) >> 4) & 0x1)
#define SIZEOF(a)               sizeof(a) / sizeof(a[0])

//------------------------------------------------------------------------------
// Global Variables
char temperatureString[] = "TEMP:00\r\0";       //Template for temperature data
bool SW_Flag = 0;
float C_Temp;
float C_Temp_Last;
uint8_t ONE_SEC = 0;

//-----------------
// ADC stuff for Temperature sensore
#define ADC_VREF  (3.25)
#define ADC_MAX    4096
#define MCP9700_V0C  (0.5)
#define MCP9700_TC   (0.01)


//------------------------------------------------------------------------------
// Functions
//------------------------------------------------------------------------------
void myAPP_Initialize(void)
{
    // GPIO register initialization for LED control.
    GPIOB_REGS->GPIO_ANSEL = GPIOB_REGS->GPIO_ANSEL & 0xFFFFFFD6;
    GPIOB_REGS->GPIO_TRIS = GPIOB_REGS->GPIO_TRIS & 0xFFFFFFD6;
    GPIOB_REGS->GPIO_PORTCLR = 0x29;    
    
    GPIOB_REGS->GPIO_ANSELSET = 0x40; /* Analog Mode Enable  RB6/AN2 */        
    GPIO_PinInputEnable(GPIO_PIN_RB6);
    
    /* Disable JTAG since at least one of its pins is configured for Non-JTAG function */
    // Need this to control Blue LED on PB5
    CFG_REGS->CFG_CFGCON0CLR = CFG_CFGCON0_JTAGEN_Msk;
    //    
    // 200mS timer
    TC3_TimerCallbackRegister(TC3_Ticker, 0);           // Interrupt handler callback    
   
    //
//    TCC0_REGS->TCC_CTRLBCLR = TCC_CTRLBCLR_LUPD(1);     // Enable double buffering
//    TCC0_REGS->TCC_CC[0] = 0;                           // PWM CH 0 output is off    
//    TCC0_REGS->TCC_CC[1] = 0;                           // PWM CH 1 output is off        
//    TCC0_PWMStart();                                    // Start the PWM
    
    TC3_TimerStart();       // Start the 200mS timer    
    
    //	
}


void myAPP_Tasks(void)
{
    //

    //
}

//------------------------------------------------------------------------------[WORKS]
// TC3 Callback Interrupt (200mS rate))
void TC3_Ticker(TC_TIMER_STATUS status, uintptr_t context)
{
    extern uint16_t conn_hdl;   // connection handle info captured @BLE_GAP_EVT_CONNECTED event    
    extern uint8_t tx_count;
    extern bool SW2_State;
    extern uint16_t ret;
    //
    ONE_SEC++;
    //
//    switch(tx_count)
//        {
//        case 0:
            if((SWITCH_Get() == 0) & (SW2_State == 0))  // Check for switch press of the user switch SW2
                {
                BLESendData((uint8_t*)"S1", 2);         // Switch is pressed  
                SW2_State = 1;
                }
            //
            if((SWITCH_Get() == 1) & (SW2_State == 1))  // Check for switch press of the user switch SW2
                {
                BLESendData((uint8_t*)"S0", 2);         // Switch is released                        
                SW2_State = 0;
                }
//            tx_count = 1;
//            break;
//        case 1:
//            tx_count = 0;
//            break;
//        }
    //
    if(ONE_SEC == 5)        // One second time period
        {
        C_Temp = MCP9700_Temp_Celsius();
        sprintf(temperatureString, "T%3.1f", C_Temp);     // Format temperature packet    
        ret = BLE_TRSPS_SendData(conn_hdl, 5, (void*)temperatureString);
        ONE_SEC = 0;
        }
    
    //
}


void BLESendData(uint8_t *data, uint8_t len)
{
    extern uint16_t conn_hdl;// connection handle info captured @BLE_GAP_EVT_CONNECTED event    
    extern uint16_t ret;
    //
    ret = BLE_TRSPS_SendData(conn_hdl, sizeof(data), data); // Send the BLE data         FUBAR ??????                
}

//------------------------------------------------------------------------------
// Send temperature over BLE
void BLESendTemperature(uint8_t temperature)
{
    extern uint16_t conn_hdl;// connection handle info captured @BLE_GAP_EVT_CONNECTED event    
    //
    extern uint16_t ret;
    char temperatureString[10];  // = "TEMP:00\r\0";    //Template for temperature data
    uint8_t t;
    double result;
    uint8_t MSB;
    uint8_t LSB;
    uint8_t tmp;
    //
    t = temperature;                // 0xF9 is 19.5C    
    if(t > 127)                     // Convert to Celcius (23 degrees reads zero, half degree per count)
        {
        result = (double)(t - 256);        
        result += 46;        
        result /= 2;                
        }
    else
        {
        result = (double)(t + 46);        
        result /= 2;                
        }
    //
    tmp = (uint8_t)(result * 10);
    MSB = (uint8_t)(tmp / 10);
    LSB = (uint8_t)(tmp - (MSB * 10));
    //
    MSB = 67;       // Test data KJD ++++++++++++++++++++++++++++
    LSB = 8;
    //
    sprintf(temperatureString, "T%2d.%1d", MSB, LSB);     // Format temperature packet    
    ret = BLE_TRSPS_SendData(conn_hdl, 5, (void*)temperatureString);
//    BLESendData((uint8_t*)temperatureString, 5);
    //
}

//------------------------------------------------------------------------------
// Reads the ADC input and converts to temperature
float MCP9700_Temp_Celsius(void)
{
	uint16_t adc_read = 0, adc_read1 = 0;
    volatile float temperature = 0, vout;
    uint8_t i = 0;
    
    /* Take 4 Samples and take the average*/
	for(i = 0; i < 5; i++)
        {
        ADCHS_GlobalEdgeConversionStart();
    
        while(!ADCHS_ChannelResultIsReady(ADCHS_CH2));
        
        adc_read1 = ADCHS_ChannelResultGet(ADCHS_CH2);
        
        if(i!=0)
            adc_read = adc_read + adc_read1;
        }
    
    adc_read = adc_read / 4;              // Calculate the average
    
    vout =  ((float)adc_read) / ((float)ADC_MAX);
        
    vout = vout * ADC_VREF;  // Convert to voltage with 3.25 V is reference
              
    // TA = (VOUT - V0�C )/TC  TC = 0.01, V0�C = 0.5v as per MCP9700/9700A datasheet
	temperature = (vout - MCP9700_V0C) / MCP9700_TC;
	
	return (temperature);
}

//------------------------------------------------------------------------------
// Microsecond delay
void __delay_uS(unsigned long int count)
{
    while(count-- > 0)
        {
        __asm("nop");           // 1
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 5
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 10
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 15
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 20
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 25
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 30
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 35
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 40
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 45
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 48
        __asm("nop");
        __asm("nop");           // 50
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 55     
        __asm("nop");
        __asm("nop");
        __asm("nop");
        __asm("nop");           // 59
        }
    //    
}

//------------------------------------------------------------------------------
// Millisecond delay
void __delay_mS(unsigned short int ms )
{
    while (ms--)
        {
        __delay_uS(1000);
        }
}

// EOF
